
python setup.py sdist