
from distutils.core import setup

setup(
    name = 'ZBox',
    version = '1.0',
    author = 'Xander-Z',
    author_email= '928457592@qq.com',
    url = 'https://github.com/Xander-Z/ZBox',
    description= 'a tool box of Xander-Z',
    packages = ['ZBox.miss_rate_eval']
)